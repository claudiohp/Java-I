package dao;

public class PessoaDao {

}
