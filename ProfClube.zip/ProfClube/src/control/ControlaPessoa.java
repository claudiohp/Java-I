package control;

public class ControlaPessoa{
	
	public void cadastroAluno(){
		
	}
}
