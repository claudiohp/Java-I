package control;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;

public class TelaCadastro extends JFrame {
	private JTextField idPessoa;
	private JTextField nome;
	private JTextField data_nascimento;
	private JTextField telefone_res;
	private JTextField telefone_cel;
	private JTextField cpf;
	private JTextField email;
	private JTextField status;
	private JTextField valor_hoa;
	private JTextField curriculo;
	private JTextField numero_aulas;
	private JTextField foto;
	private JTextField login;
	private JTextField tipo_pessoa;
	private JTextField avaliacao;
	private JPasswordField senha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaCadastro frame = new TelaCadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaCadastro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 640, 480);
		
		JPanel panel = new JPanel();
		
		JPanel panel_1 = new JPanel();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 289, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 292, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(15, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 420, GroupLayout.PREFERRED_SIZE)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 420, Short.MAX_VALUE))
					.addContainerGap())
		);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		
		JLabel lblNewLabel_2 = new JLabel("Login:");
		
		login = new JTextField();
		login.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha:");
		
		senha = new JPasswordField();
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblNewLabel_2)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(login, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addComponent(lblSenha)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(senha)))
					.addContainerGap(144, Short.MAX_VALUE))
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap(201, Short.MAX_VALUE)
					.addComponent(btnCadastrar)
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(login, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSenha)
						.addComponent(senha, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(329)
					.addComponent(btnCadastrar)
					.addContainerGap())
		);
		panel_1.setLayout(gl_panel_1);
		
		JLabel lblIdPessoa = new JLabel("Matr\u00EDcula:");
		
		idPessoa = new JTextField();
		idPessoa.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		
		nome = new JTextField();
		nome.setColumns(10);
		
		JLabel lbldata_nascimento = new JLabel("Data de nascimento:");
		
		data_nascimento = new JTextField();
		data_nascimento.setColumns(10);
		
		JLabel lbltelefone_res = new JLabel("Telefone res.:");
		
		telefone_res = new JTextField();
		telefone_res.setColumns(10);
		
		JLabel lbltelefone_cel = new JLabel("Telefone cel.:");
		
		telefone_cel = new JTextField();
		telefone_cel.setColumns(10);
		
		JLabel lblCpf = new JLabel("CPF:");
		
		JLabel lblEmail = new JLabel("E-mail:");
		
		JLabel lblStatus = new JLabel("Status:");
		
		JLabel lblValorHa = new JLabel("Valor H/A:");
		
		JLabel lblNewLabel = new JLabel("Curr\u00EDculo:");
		
		JLabel lblNDeAulas = new JLabel("N\u00BA de aulas:");
		
		JLabel lblNewLabel_1 = new JLabel("Foto (diret\u00F3rio):");
		
		JLabel lblTipoDePessoa = new JLabel("Tipo de pessoa:");
		
		JLabel lblAvaliacao = new JLabel("Avalia\u00E7\u00E3o:");
		
		cpf = new JTextField();
		cpf.setColumns(10);
		
		email = new JTextField();
		email.setColumns(10);
		
		status = new JTextField();
		status.setColumns(10);
		
		valor_hoa = new JTextField();
		valor_hoa.setColumns(10);
		
		curriculo = new JTextField();
		curriculo.setColumns(10);
		
		numero_aulas = new JTextField();
		numero_aulas.setColumns(10);
		
		foto = new JTextField();
		foto.setColumns(10);
		
		tipo_pessoa = new JTextField();
		tipo_pessoa.setColumns(10);
		
		avaliacao = new JTextField();
		avaliacao.setColumns(10);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel.createSequentialGroup()
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(lblIdPessoa)
										.addComponent(lblNome))
									.addGap(18)
									.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
										.addComponent(idPessoa)
										.addComponent(nome, GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE)))
								.addGroup(gl_panel.createSequentialGroup()
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(lbldata_nascimento)
										.addComponent(lbltelefone_res))
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(telefone_res, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(data_nascimento, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(telefone_cel, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(cpf, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(email, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(status, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(valor_hoa, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(curriculo, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(numero_aulas, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
										.addComponent(foto, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE))))
							.addGap(75))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lbltelefone_cel)
							.addContainerGap(213, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblCpf)
							.addContainerGap(256, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblEmail)
							.addContainerGap(247, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblStatus)
							.addContainerGap(244, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblValorHa)
							.addContainerGap(230, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addContainerGap(233, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNDeAulas)
							.addContainerGap(220, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(lblNewLabel_1)
							.addContainerGap(202, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblTipoDePessoa)
								.addComponent(lblAvaliacao)
								.addGroup(gl_panel.createSequentialGroup()
									.addGap(109)
									.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(avaliacao, GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
										.addComponent(tipo_pessoa, GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE))))
							.addContainerGap(43, GroupLayout.PREFERRED_SIZE))))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblIdPessoa)
						.addComponent(idPessoa, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNome)
						.addComponent(nome, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbldata_nascimento)
						.addComponent(data_nascimento, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbltelefone_res)
						.addComponent(telefone_res, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbltelefone_cel)
						.addComponent(telefone_cel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCpf)
						.addComponent(cpf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEmail)
						.addComponent(email, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblStatus)
						.addComponent(status, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblValorHa)
						.addComponent(valor_hoa, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel)
						.addComponent(curriculo, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNDeAulas)
						.addComponent(numero_aulas, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(foto, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTipoDePessoa)
						.addComponent(tipo_pessoa, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAvaliacao)
						.addComponent(avaliacao, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(46, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		getContentPane().setLayout(groupLayout);
	}
}
