package model;

public class Pessoa {
	
	private int idPessoa;
	private String nome;
	private String data_nascimento;
	private String telefone_res;
	private String telefone_cel;
	private String cpf;
	private String email;
	private String status;
	private String valor_hoa;
	private String curriculo;
	private String numero_aulas;
	private String foto;
	private String login;
	private String senha;
	private String tipo_pessoa;
	private String avaliacao;
	public int getIdPessoa() {
		return idPessoa;
	}
	
	public void setIdPessoa(int idPessoa) {
		this.idPessoa = idPessoa;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getData_nascimento() {
		return data_nascimento;
	}
	public void setData_nascimento(String data_nascimento) {
		this.data_nascimento = data_nascimento;
	}
	public String getTelefone_res() {
		return telefone_res;
	}
	public void setTelefone_res(String telefone_res) {
		this.telefone_res = telefone_res;
	}
	public String getTelefone_cel() {
		return telefone_cel;
	}
	public void setTelefone_cel(String telefone_cel) {
		this.telefone_cel = telefone_cel;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getValor_hoa() {
		return valor_hoa;
	}
	public void setValor_hoa(String valor_hoa) {
		this.valor_hoa = valor_hoa;
	}
	public String getCurriculo() {
		return curriculo;
	}
	public void setCurriculo(String curriculo) {
		this.curriculo = curriculo;
	}
	public String getNumero_aulas() {
		return numero_aulas;
	}
	public void setNumero_aulas(String numero_aulas) {
		this.numero_aulas = numero_aulas;
	}
	public String getFoto() {
		return foto;
	}
	public void setFoto(String foto) {
		this.foto = foto;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getTipo_pessoa() {
		return tipo_pessoa;
	}
	public void setTipo_pessoa(String tipo_pessoa) {
		this.tipo_pessoa = tipo_pessoa;
	}
	public String getAvaliacao() {
		return avaliacao;
	}
	public void setAvaliacao(String avaliacao) {
		this.avaliacao = avaliacao;
	}
}